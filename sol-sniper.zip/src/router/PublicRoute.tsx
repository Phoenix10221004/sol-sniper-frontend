import React from "react";
import { Route } from "react-router-dom";

import styles from '../styles/PrivateRoute.module.scss';
import Header from "../components/Header";
import Sidebar from "../components/Sidebar";

const PublicRoute = ({ component: Component, ...restOfProps }) => {

  return (
    <div className={styles.div}>
      <Sidebar />
      <div className={styles.container}>
        <Header title={restOfProps.title} />
        <div className={styles.content}>
          <div className="container">
            <Route render={(props) => <Component {...props} />} />
          </div>
        </div>
      </div>
    </div>

  )
}

export default PublicRoute;