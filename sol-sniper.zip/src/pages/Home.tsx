import React from "react";

import { useAnchorWallet } from "@solana/wallet-adapter-react";
import { WalletMultiButton } from "@solana/wallet-adapter-react-ui";
import styles from '../styles/Home.module.scss';

const Home = () => {

    const wallet = useAnchorWallet()

    return (
        <div className={styles.div}>
            {!wallet && <>
                <div className={styles.subTitle}>
                    Welcome,
                </div>
                <div className={styles.subTitle}>
                    Please connect your wallet <br />
                    to use the Snapshot Sniper.
                </div>
            </>}
            {wallet && <div className={styles.subTitle}>
                Continue to the Live Listing <br />
                page to the Snapshot Sniper
            </div>}
            <div className={styles.text}>
                Customize the sniper specifications to your needs and get sniping. For assistance, reach <br />
                out to the community or the moderators within the Snapshots Discord.
            </div>
            {!wallet && <WalletMultiButton className={styles.wallet} />}
            {wallet && <div className={styles.wallet} >Connected</div>}
        </div>
    )
}

export default Home