
import styles from '../styles/Header.module.scss';

const Header = (props) => {

    return (
        <div className={styles.div}>
            <div className={styles.title}>
                {props.title}
            </div>
        </div>
    )
}

export default Header