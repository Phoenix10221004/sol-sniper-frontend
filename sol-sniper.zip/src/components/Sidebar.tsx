import { NavLink } from 'react-router-dom'
import { WalletMultiButton } from "@solana/wallet-adapter-react-ui";

import { useAnchorWallet } from "@solana/wallet-adapter-react";

import Brightness4Icon from '@mui/icons-material/Brightness4';
import CellTowerIcon from '@mui/icons-material/CellTower';
import HistoryIcon from '@mui/icons-material/History';

import { getImg } from "../utils/Helper";
import styles from '../styles/Sidebar.module.scss';
import '../styles/Wallet.scss'

const Sidebar = () => {

  const wallet = useAnchorWallet()

  return (
    <div className={styles.div}>
      <div>
        <NavLink to="/" className={styles.logo}>
          <img src={getImg('logo.png')} alt="log" />
          <p>Sniper</p>
        </NavLink>
        <NavLink to="/home" className={styles.menu} activeClassName={styles.acitve}>
          <img src={getImg('home.png')} alt="log" />
          Home
        </NavLink>
        <NavLink to="/live" className={`${styles.menu} ${!wallet && styles.disable}`} activeClassName={styles.acitve}>
          <CellTowerIcon /> Live Listing
        </NavLink>
        <NavLink to="/activity" className={`${styles.menu} ${!wallet && styles.disable}`} activeClassName={styles.acitve}>
          <HistoryIcon /> Activities
        </NavLink>
      </div>
      <div>
        <WalletMultiButton className={styles.wallet} />
        <div className={styles.social}>
          <a href='https://discord.gg/snapshots' target='_blank'><img src={getImg('discord.png')} alt="discord" /></a>
          <a href='https://twitter.com/SnapShotsNFT' target='_blank'><img src={getImg('twitter.png')} alt="twitter" /></a>
          <Brightness4Icon />
        </div>
      </div >
    </div >
  )
}

export default Sidebar